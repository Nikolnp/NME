/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.ac.city.acvt745.nme.domain;

import java.util.Date;
import java.util.HashSet;
import javax.persistence.*;

/**
 *
 * @author NIKOLETA
 */
@Entity
public class Track {
    @Column
    @Id
    private int trackId;
    @Column
    private String trackName;
    @Column
    private float duration;
    @Column
    private Date recordingDate;
    
    @ManyToOne
    @JoinColumn(name="artistId")
    private Artist artist;
    
    @ManyToOne
    @JoinColumn(name="albumId")
    private Album album;
    
    
    public Track() {
        
    }

    public int getTrackId() {
        return trackId;
    }

    public void setTrackId(int trackId) {
        this.trackId = trackId;
    }

    public String getTrackName() {
        return trackName;
    }

    public void setTrackName(String trackName) {
        this.trackName = trackName;
    }

    public float getDuration() {
        return duration;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

    public Date getRecordingDate() {
        return recordingDate;
    }

    public void setRecordingDate(Date recordingDate) {
        this.recordingDate = recordingDate;
    }

    public Artist getArtist() {
        return artist;
    }

    public void setArtist(Artist artist) {
        this.artist = artist;
    }

    public Album getAlbum() {
        return album;
    }

    public void setAlbum(Album album) {
        this.album = album;
    }

    @Override
    public String toString() {
        return "Track{" + "trackId=" + trackId + ", trackName=" + trackName + 
                ", duration=" + duration + ", recordingDate=" + recordingDate
                +", album="+album.getAlbumTitle() + ", artist="+artist.getArtistName()+'}';
    }

   

 
    
}
